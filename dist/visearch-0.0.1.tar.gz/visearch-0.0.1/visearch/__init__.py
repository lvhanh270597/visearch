name = "visearch"
from visearch.model.search import Searcher
